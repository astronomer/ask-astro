from __future__ import annotations

from pathlib import Path
import json
from time import sleep
from typing import TYPE_CHECKING, Any, Optional, Sequence, Callable, Collection, Mapping, List, Dict, Iterable, Literal
import tempfile
import io
from urllib import parse as url_parse
import warnings

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator, BaseOperatorLink
from airflow.operators.branch import BaseBranchOperator

from airflow.lineage import prepare_lineage

import pandas as pd
from weaviate.util import generate_uuid5

from weaviate_provider.hooks.weaviate import WeaviateHook
from weaviate_provider.triggers.weaviate import WeaviateBackupTrigger, WeaviateRestoreTrigger

from weaviate.exceptions import UnexpectedStatusCodeException
import weaviate

if TYPE_CHECKING:
    from airflow.utils.context import Context

class WeaviateOperatorRegistryLink(BaseOperatorLink):

    name = "Astronomer Registry"

    def get_link(self, operator: BaseOperator, *, ti_key=None):
        return "https://registry.astronomer.io/providers/airflow-provider-weaviate/versions/latest"

class _WeaviateBaseOperator(BaseOperator):
    """
    Base operator class for weaviate operators

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str
    
    """
    template_fields: Sequence[str] = (*BaseOperator.template_fields,"templates_dict", "op_args", "op_kwargs")
    template_fields_renderers = {"templates_dict": "json", "op_args": "py", "op_kwargs": "py"}

    # ui_color = "#fa0171"  #weaviate pink
    ui_color = "#84DB26"    #weaviate light green
    # ui_color = "#0A6A5F"  #weaviate dark green
    # ui_color = "#1B1464"  #weaviate purple

    operator_extra_links = (WeaviateOperatorRegistryLink(),)

    def __init__(
        self,
        *,
        weaviate_conn_id: str = WeaviateHook.default_conn_name,
        python_callable: Callable | None = None,
        op_args: Collection[Any] | None = None,
        op_kwargs: Mapping[str, Any] | None = None,
        templates_dict: dict[str, Any] | None = None,
        templates_exts: Sequence[str] | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.weaviate_conn_id = weaviate_conn_id
        self.hook = WeaviateHook(weaviate_conn_id=weaviate_conn_id)
        self.python_callable = python_callable
        self.op_args = op_args or ()
        self.op_kwargs = op_kwargs or {}
        self.templates_dict = templates_dict
        if templates_exts:
            self.template_ext = templates_exts

    def _check_schema(self, class_object:Any, class_schema:Any):
        "Recursively check object against schema"

        if class_object == class_schema:
            return True
        
        if isinstance(class_object, dict) and isinstance(class_schema, dict):
            if class_object.items() <= class_schema.items():
                return True
            else:
                return all([self._check_schema(class_object[k], class_schema[k]) for k in class_object.keys()])
        
        elif isinstance(class_object, (list, tuple)) and type(class_object)==type(class_schema):
            return all([self._check_schema(item[0], item[1]) for item in zip(class_object,class_schema)])
            
        else:
            return False

    def _get_file(self, uri:str, storage_conn_id:str | None = None):
        """
        Gets a data (parquet) or schema (json) file from Weaviate supported file sources 
        (local filesystem, s3, gcs, azure) and returns a dict or pandas dataframe.

        For cloud storage an Airflow connection must be created according to:
        https://airflow.apache.org/docs/apache-airflow-providers-amazon/stable/connections/aws.html
        https://airflow.apache.org/docs/apache-airflow-providers-google/stable/connections/gcp.html
        https://airflow.apache.org/docs/apache-airflow-providers-microsoft-azure/stable/connections/adls_v2.html
        
        Example URIs:    

        uri = 'file://include/data/schema.json'
        uri = 'file:///usr/local/airflow/include/data/books.parquet'
        uri = 's3://weaviateprovidertest/include/data/books.parquet'
        uri = 's3://weaviateprovidertest/include/data/schema.json'
        uri = 'gs://weaviateprovidertest1/include/data/books.parquet'
        uri = 'gs://weaviateprovidertest1/include/data/schema.json'
        uri = 'abfss://data@weaviateprovidertest.dfs.core.windows.net/include/data/books.parquet'
        uri = 'abfss://data/include/data/schema.json'

        file_data = self._get_file(uri, 'azure_data_lake_default')
        file_data = self._get_file(uri, 'minio_default')
        file_data = self._get_file(uri, 'aws_default')
        file_data = self._get_file(uri, 'google_cloud_default')
        
        """

        parsed_url = url_parse.urlparse(uri)
        file_path = '/'.join(parsed_url.path.split('/')[1:])
        file_type = Path(file_path).suffix

        if parsed_url.scheme == 'file':
            file_name = Path(parsed_url.netloc+parsed_url.path)

            if file_name.is_file() and file_name.exists():
                file_data = file_name.read_bytes()

        elif parsed_url.scheme == 's3':
            from airflow.providers.amazon.aws.hooks.s3 import S3Hook

            if not storage_conn_id:
                storage_conn_id = 'aws_default'
            
            hook = S3Hook(storage_conn_id)
            assert hook.check_for_bucket(parsed_url.netloc), f"Bucket {parsed_url.netloc} not found."
            assert hook.check_for_key(key=file_path, bucket_name=parsed_url.netloc), f"Key {file_path} not found in bucket {parsed_url.netloc}."
            file_obj = hook.get_key(key=file_path, bucket_name=parsed_url.netloc)

            with tempfile.NamedTemporaryFile() as tf:
                file_obj.download_file(tf.name)
                file_data = Path(tf.name).read_bytes()

        elif parsed_url.scheme == 'gs':
            from airflow.providers.google.cloud.hooks.gcs import GCSHook

            if not storage_conn_id:
                storage_conn_id = 'google_cloud_default'

            hook = GCSHook(storage_conn_id)
            
            try: 
                bucket_list = hook.list(parsed_url.netloc)
                assert file_path in bucket_list
                file_data = hook.download_as_byte_array(parsed_url.netloc, file_path)
            except Exception as e:
                raise AirflowException(f'Could not access file contents at {uri}.  Error is {e}')

        elif parsed_url.scheme in ['abfss', 'abfs']:
            from airflow.providers.microsoft.azure.hooks.data_lake import AzureDataLakeStorageV2Hook
            import logging
            logger = logging.getLogger("azure.core.pipeline.policies.http_logging_policy")
            logger.setLevel(logging.WARNING)

            if not storage_conn_id:
                storage_conn_id = 'AZURE_DATA_LAKE_DEFAULT'

            hook = AzureDataLakeStorageV2Hook(storage_conn_id)

            if '@' in parsed_url.netloc:
                file_system_name = parsed_url.netloc.split('@')[0]
                account = parsed_url.netloc.split('@')[1]
            else:
                file_system_name = parsed_url.netloc

            file_system = hook.get_file_system(file_system=file_system_name)
            if file_system.exists(): 
                file_client = file_system.get_file_client(file_path=file_path)
                if file_client.exists():
                    file_data = file_client.download_file().readall()
                else:
                    raise AirflowException(f"File at '{file_client.path_name}' does not exist or is not accessible.")
            else:
                raise AirflowException(f"Filesystem '{file_system.file_system_name}' does not exist or is not accessible.")
        else:
            raise AirflowException(f'Unsupported file uri {parsed_url.scheme}')
        
        if file_type == '.json':
            return json.loads(file_data.decode())
        elif file_type == '.parquet':
            return pd.read_parquet(io.BytesIO(file_data))
        else:
            raise AirflowException(f'Unsupported file type {file_type}')

    def _put_file(self, file_data:str, uri:str, storage_conn_id:str | None = None):
        """
        Puts the contents of a json object or pandas dataframe file data to Weaviate supported file sources 
        (local filesystem, s3, gcs, azure) at location specified by uri.  Operation will fail if file exists.

        For cloud storage an Airflow connection must be created according to:
        https://airflow.apache.org/docs/apache-airflow-providers-amazon/stable/connections/aws.html
        https://airflow.apache.org/docs/apache-airflow-providers-google/stable/connections/gcp.html
        https://airflow.apache.org/docs/apache-airflow-providers-microsoft-azure/stable/connections/adls_v2.html
        
        Example URIs:    

        uri = 'file://include/data/schema.json'
        uri = 'file:///usr/local/airflow/include/data/books.parquet'
        uri = 's3://weaviateprovidertest/include/data/books_out1.parquet'
        uri = 's3://weaviateprovidertest/include/data/schema_out.json'
        uri = 'gs://weaviateprovidertest1/include/data/books_out.parquet'
        uri = 'gs://weaviateprovidertest1/include/data/schema_out1.json'
        uri = 'abfss://data@weaviateprovidertest.dfs.core.windows.net/include/data/books_out.parquet'
        uri = 'abfss://data/include/data/schema_out.json'

        file_data = self._get_file(uri, 'minio_default')
        self._put_file(file_data=file_data, uri=uri, storage_conn_id='minio_default')
        
        """

        parsed_url = url_parse.urlparse(uri)
        file_path: Path | str = '/'.join(parsed_url.path.split('/')[1:])
        file_type = Path(file_path).suffix

        if parsed_url.scheme == 'file':
            file_path = Path(parsed_url.netloc+parsed_url.path)

            if file_path.exists():
                if self.replace_existing:
                    file_path.unlink()
                else:
                    raise AirflowException(f"File already exists at {file_path.as_posix()}, and replace_existing=False.")

            if isinstance(file_data, dict) and file_type == '.json':
                try:
                    file_path.write_text(json.dumps(file_data))
                except Exception as e:
                    raise AirflowException(f'Could not write file contents to {file_path.as_posix()}. Error: {e}')
            elif isinstance(file_data, pd.DataFrame) and file_type == '.parquet':
                try:
                    file_data.to_parquet(file_path.as_posix())
                except Exception as e:
                    raise AirflowException(f'Could not write file contents to {file_path.as_posix()}. Error: {e}')
            else: 
                raise AirflowException(f'Unsupported data type or file extension.  dict -> .json, pd.DataFrame -> .parquet')

        elif parsed_url.scheme == 's3':
            from airflow.providers.amazon.aws.hooks.s3 import S3Hook

            if not storage_conn_id:
                storage_conn_id = 'aws_default'
            
            hook = S3Hook(storage_conn_id)
            assert hook.check_for_bucket(parsed_url.netloc), f"Bucket {parsed_url.netloc} not found."

            if hook.check_for_key(key=file_path, bucket_name=parsed_url.netloc):
                if self.replace_existing:
                    hook.delete_objects(keys=file_path, bucket=parsed_url.netloc)
                else:
                    raise AirflowException(f"File already exists at {file_path}, and replace_existing=False.")
                
            if isinstance(file_data, dict) and file_type == '.json':
                try:
                    hook.load_string(string_data=json.dumps(file_data), key=file_path, bucket_name=parsed_url.netloc)
                except Exception as e:
                    raise AirflowException(f'Could not write file contents to {uri}. Error: {e}')
            elif isinstance(file_data, pd.DataFrame) and file_type == '.parquet':
                try:
                    hook.load_bytes(bytes_data=file_data.to_parquet(), key=file_path, bucket_name=parsed_url.netloc)
                except Exception as e:
                    raise AirflowException(f'Could not write file contents to {file_path}. Error: {e}')
            else: 
                raise AirflowException(f'Unsupported data type or file extension.  dict -> .json, pd.DataFrame -> .parquet')

        elif parsed_url.scheme == 'gs':
            from airflow.providers.google.cloud.hooks.gcs import GCSHook

            if not storage_conn_id:
                storage_conn_id = 'google_cloud_default'

            hook = GCSHook(storage_conn_id)
            
            try: 
                bucket_list = hook.list(parsed_url.netloc)
                if file_path in bucket_list:
                    if self.replace_existing:
                        hook.delete(object_name=file_path, bucket_name=parsed_url.netloc)
                    else:
                        raise AirflowException(f"File already exists at {file_path}, and replace_existing=False.")
                    
                if isinstance(file_data, dict) and file_type == '.json':
                    try:
                        hook.upload(data=json.dumps(file_data), object_name=file_path, bucket_name=parsed_url.netloc)
                    except Exception as e:
                        raise AirflowException(f'Could not write file contents to {uri}. Error: {e}')
                elif isinstance(file_data, pd.DataFrame) and file_type == '.parquet':
                    try:
                        hook.upload(data=file_data.to_parquet(), object_name=file_path, bucket_name=parsed_url.netloc)
                    except Exception as e:
                        raise AirflowException(f'Could not write file contents to {file_path}. Error: {e}')
                else: 
                    raise AirflowException(f'Unsupported data type or file extension.  dict -> .json, pd.DataFrame -> .parquet')
            except Exception as e:
                raise AirflowException(f'Could not write file contents at {uri}.  Error is {e}')

        elif parsed_url.scheme in ['abfss', 'abfs']:
            from airflow.providers.microsoft.azure.hooks.data_lake import AzureDataLakeStorageV2Hook
            import logging
            logger = logging.getLogger("azure.core.pipeline.policies.http_logging_policy")
            logger.setLevel(logging.WARNING)

            if not storage_conn_id:
                storage_conn_id = 'AZURE_DATA_LAKE_DEFAULT'

            hook = AzureDataLakeStorageV2Hook(storage_conn_id)

            if '@' in parsed_url.netloc:
                file_system_name = parsed_url.netloc.split('@')[0]
                account = parsed_url.netloc.split('@')[1]
            else:
                file_system_name = parsed_url.netloc

            file_system = hook.get_file_system(file_system=file_system_name)
            if file_system.exists():
                file_client = file_system.get_file_client(file_path=file_path)
                if file_client.exists():
                    if self.replace_existing:
                        file_client.delete_file()
                    else:
                        raise AirflowException(f"File already exists at {file_path}, and replace_existing=False.")
                                
                file_client.create_file()
                
                if isinstance(file_data, dict) and file_type == '.json':
                    try:
                        file_client.upload_data(data=json.dumps(file_data), overwrite=True)
                    except Exception as e:
                        raise AirflowException(f'Could not write file contents to {uri}. Error: {e}')
                elif isinstance(file_data, pd.DataFrame) and file_type == '.parquet':
                    try:
                        file_client.upload_data(data=file_data.to_parquet(), overwrite=True)
                    except Exception as e:
                        raise AirflowException(f'Could not write file contents to {file_path}. Error: {e}')
                else: 
                    raise AirflowException(f'Unsupported data type or file extension.  dict -> .json, pd.DataFrame -> .parquet')
            else:
                raise AirflowException(f"Filesystem '{file_system.file_system_name}' does not exist or is not accessible.")
        else:
            raise AirflowException(f'Unsupported file uri {parsed_url.scheme}')
        
        return uri

class WeaviateBackupOperator(_WeaviateBaseOperator):
    """
    Asynchronously restore a weaviate vector database from Local filesystem, 
    S3/Minio, GCS or ADLS. 

    By default the operator defers after 'timeout' seconds (default: 2).  By 
    setting 'wait'=True the operator runs syncronously and does not defer.

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param backend: Backend source to use for backup.  The Weaviate instance 
    must be configured with 'ENABLE_MODULES' for the backend provided as 
    per https://weaviate.io/developers/weaviate/configuration/backups. Current 
    options are 'backup-s3', 'backup-gcs', 'backup-azure', 'backup-filesystem'
    :type backend: str

    :param id: The id of the backup. This string must be provided on all future 
    tasks such as WeaviateRestoreOperator
    :type id: str

    :param include: An optional list of class names to be included in the restore. 
    If not set, all classes are included.
    :type include: list

    :param exclude: An optional list of class names to be excluded from the restore. 
    If not set, no classes are excluded.
    :type exclude: list

    :param wait: Whether to run synchronously and wait for completion.
    :type wait: boolean
    
    :param timeout: Time (seconds) to wait before asyncronous deferral. 
    (Default: 2 seconds)
    :type timeout: int
    
    """
    # Specify the arguments that are allowed to parse with jinja templating
    template_fields = [
        *_WeaviateBaseOperator.template_fields,
        'id'
    ]
    template_fields_renderers = {"id": "text"}
    template_ext = ()

    # ui_color = "#84DB26"    #light green

    def __init__(
        self,
        backend:str,
        id:str,
        include:list[str] | None = None,
        exclude:list[str] | None = None,
        wait:bool = False,
        timeout:int = 2,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        
        if include and exclude:
            raise AirflowException("Only one of include or exclude can be set")
        self.backend = backend
        self.id = id
        self.include = include
        self.exclude = exclude
        self.wait = wait
        self.timeout = timeout
        
    def execute(self, context: Context, event=None) -> Any:
        self.client = self.hook.get_conn()

        if event: 
            return event

        if self.wait:
            response = self.client.backup.create(
                backup_id=self.id, 
                backend=self.backend,
                include_classes=self.include,
                exclude_classes=self.exclude,
                wait_for_completion=True
                )
        else:
            response = self.client.backup.create(
                backup_id=self.id, 
                backend=self.backend,
                include_classes=self.include,
                exclude_classes=self.exclude,
                wait_for_completion=False
                )
            
            sleep(self.timeout)

            response = self.client.backup.get_create_status(backend=self.backend, 
                                                            backup_id=self.id)
            
            if response['status'] == 'SUCCESS':
                return response
            else:
                self.defer(method_name='execute',
                           trigger=WeaviateBackupTrigger(task_id=self.task_id,
                                                         weaviate_conn_id=self.weaviate_conn_id,
                                                         backend=self.backend,
                                                         id=self.id
                                                ),
                            timeout=None,
                            kwargs=None,
                           )        

class WeaviateRestoreOperator(_WeaviateBaseOperator):
    """
    Asynchronously restore a weaviate vector database from Local filesystem, 
    S3/Minio, GCS or ADLS. 

    By default the operator defers after 'timeout' seconds (default: 2).  By 
    setting 'wait'=True the operator runs syncronously and does not defer.

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param backend: Backend source to use for backup.  The Weaviate instance 
    must be configured with 'ENABLE_MODULES' for the backend provided as 
    per https://weaviate.io/developers/weaviate/configuration/backups. Current 
    options are 'backup-s3', 'backup-gcs', 'backup-azure', 'backup-filesystem'
    :type backend: str

    :param id: The id of the backup. This string must be provided on all future 
    tasks such as WeaviateRestoreOperator
    :type id: str

    :param include: An optional list of class names to be included in the restore. 
    If not set, all classes are included.
    :type include: list

    :param exclude: An optional list of class names to be excluded from the restore. 
    If not set, no classes are excluded.
    :type exclude: list

    :param wait: Whether to run synchronously and wait for completion.
    :type wait: boolean
    
    :param timeout: Time (seconds) to wait before asyncronous deferral. 
    (Default: 2 seconds)
    :type timeout: int

    :param replace_existing: Whether to delete existing classes before restore.
    :type replace_existing: boolean
    
    """
    # Specify the arguments that are allowed to parse with jinja templating
    template_fields = [
        *_WeaviateBaseOperator.template_fields,
        'id'
    ]
    template_fields_renderers = {"id": "text"}
    template_ext = ()

    # ui_color = "#84DB26"    #light green

    def __init__(
        self,
        backend:str,
        id:str,
        include:list[str] | None = None,
        exclude:list[str] | None = None,
        wait:bool = False,
        timeout:int = 2,
        replace_existing=False,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        
        if include and exclude:
            raise AirflowException("Only one of include or exclude can be set")
        self.backend = backend
        self.id = id
        self.include = include
        self.exclude = exclude
        self.wait = wait
        self.timeout = timeout
        self.replace_existing = replace_existing
        
    def execute(self, context: Context, event=None) -> Any:
        self.client = self.hook.get_conn()

        if event: 
            return event

        if self.replace_existing:
            if not self.include:
                raise AirflowException("Must specify a list of classes with 'include' in order to use 'replace_existing'")
            
            current_class_objects = [class_object['class'] for class_object in self.client.schema.get()['classes']]
            if current_class_objects != []:
                for class_object in self.include:
                    if class_object in current_class_objects:
                        self.client.schema.delete_class(class_name=class_object)
                    else:
                        print(f"Requested to replace existing object {class_object} which does not exist. Skipping.")

        if self.wait:
            response = self.client.backup.restore(
                backup_id=self.id, 
                backend=self.backend,
                include_classes=self.include,
                exclude_classes=self.exclude,
                wait_for_completion=True
                )
        else:
            response = self.client.backup.restore(
                backup_id=self.id, 
                backend=self.backend,
                include_classes=self.include,
                exclude_classes=self.exclude,
                wait_for_completion=False
                )
            
            sleep(self.timeout)

            response = self.client.backup.get_restore_status(backend=self.backend, 
                                                             backup_id=self.id)
            
            if response['status'] == 'SUCCESS':
                return response
            else:
                self.defer(method_name='execute',
                           trigger=WeaviateRestoreTrigger(task_id=self.task_id,
                                                          weaviate_conn_id=self.weaviate_conn_id,
                                                          backend=self.backend,
                                                          id=self.id
                                                ),
                            timeout=None,
                            kwargs=None,
                           )        

class WeaviateCreateSchemaOperator(_WeaviateBaseOperator):
    """
    Create weaviate vector database schema from a JSON formatted text object 
    and, if successful, returns the class objects dictionary to xcom.

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param class_object_data: JSON-formatted string or a path to a text file 
    (ie. file://, s3://, gcs://, abfss://) containing the class object definition.
    :type class_object_data: str

    :param storage_conn_id: If specifying a file in cloud storage specify a conn_id 
    for reading the file.
    :type storage_conn_id: str

    :param existing: If the current schema includes the data object should the 
    task 'fail' (default), 'replace' or 'ignore'.
    :type existing: str
    
    """

    def __init__(
        self,
        class_object_data:str,
        existing:str = 'fail',
        storage_conn_id:str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.class_object_data = class_object_data
        self.existing = existing
        self.storage_conn_id = storage_conn_id

        if self.existing not in ['fail', 'replace', 'ignore']:
            raise AirflowException("Invalid parameter for 'existing'.  Choices are 'fail', 'replace', 'ignore'")
        
        if not isinstance(self.class_object_data, str):
            raise AirflowException("Parameter 'class_data_object' must be passed as a string")
        
    def execute(self, context: Context) -> Any:
        self.client = self.hook.get_conn()

        try:
            class_objects = json.loads(self.class_object_data)
        except:
            class_objects = self._get_file(uri=self.class_object_data, storage_conn_id=self.storage_conn_id)

        # user specified a single class object
        if "classes" not in class_objects:
            class_objects = [class_objects]
        # user specified a list of class objects
        else:
            class_objects = class_objects["classes"]

        current_class_objects = [class_object['class'] for class_object in self.client.schema.get()['classes']]

        for class_object in class_objects:
            if class_object['class'] in current_class_objects:
                
                if self.existing == 'fail':
                    raise AirflowException(f"Trying to create class {class_object['class']} but this class already exists.")
                
                elif self.existing == 'replace':
                    print(f"Deleting existing class {class_object['class']}")
                    self.client.schema.delete_class(class_name=class_object['class'])

                elif self.existing == 'ignore':
                    print(f"Ignoring existing class {class_object['class']}")
                    continue

            self.client.schema.create_class(class_object)
            print(f"Created class {class_object['class']}")
                
        return class_objects
    
class WeaviateCheckSchemaOperator(_WeaviateBaseOperator):
    """
    Check the current weaviate vector database schema against a JSON formatted 
    text objects. Returns boolean True if the objects are a subset of the current 
    schema.  Otherwise returns False.

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param class_object_data: JSON-formatted string or a path to a text file 
    (ie. file://, s3://, gcs://, abfss://) containing the class object definition.
    :type class_object_data: str

    :param storage_conn_id: If specifying a file in cloud storage specify a conn_id 
    for reading the file.
    :type storage_conn_id: str
    
    """

    # ui_color = "#0A6A5F"    #dark green

    def __init__(
        self,
        class_object_data:str,
        storage_conn_id:str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.class_object_data = class_object_data
        self.storage_conn_id = storage_conn_id

        if not isinstance(self.class_object_data, str):
            raise AirflowException("Parameter 'class_data_object' must be passed as a string")
        
    def execute(self, context: Context) -> Any:
        self.client = self.hook.get_conn()

        try:
            class_object = json.loads(self.class_object_data)
        except:
            class_object = self._get_file(uri=self.class_object_data, storage_conn_id=self.storage_conn_id)
        
        # check if class_object is a single class object or a list of class objects
        if isinstance(class_object, dict):
            if "classes" not in class_object:
                class_objects = [class_object]
            else:
                class_objects = class_object["classes"]
        else:
            class_objects = class_object
        
        missing_objects = []

        for class_object in class_objects:
            try:
                class_schema = self.client.schema.get(class_object['class'])
                if not self._check_schema(class_object=class_object, class_schema=class_schema):
                    missing_objects.append(class_object['class'])
            except Exception as e:
                if isinstance(e, UnexpectedStatusCodeException):
                    if e.status_code == 404 and 'with response body: None.' in e.message:
                        missing_objects.append(class_object['class'])
                    else:
                        raise(e)
                else:
                    raise(e)

        if missing_objects:    
            print(f"Classes {missing_objects} are not in the current schema.")
            return False
        else:
            return True
            
class WeaviateCheckSchemaBranchOperator(_WeaviateBaseOperator, BaseBranchOperator):
    """
    Check the current weaviate vector database schema against a JSON formatted 
    text objects. This is a branch operator that will branch to downstream tasks


    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param true_tasks: A list of tasks to call downstream if schema exists.
    :type true_tasks: list
    
    :param false_tasks: A list of tasks to call downstream if schema does
     NOT exist.
    :type false_tasks: list

    :param class_object_data: JSON-formatted string or a path to a text file 
    (ie. file://, s3://, gcs://, abfss://) containing the class object definition.
    :type class_object_data: str

    :param storage_conn_id: If specifying a file in cloud storage specify a conn_id 
    for reading the file.
    :type storage_conn_id: str
    
    """

    def __init__(
        self,
        follow_task_ids_if_true: str | Iterable[str],
        follow_task_ids_if_false: str | Iterable[str],
        class_object_data:str,
        storage_conn_id:str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.true_tasks = follow_task_ids_if_true
        self.false_tasks = follow_task_ids_if_false
        self.class_object_data = class_object_data
        self.storage_conn_id = storage_conn_id

        if not isinstance(self.class_object_data, str):
            raise AirflowException("Parameter 'class_data_object' must be passed as a string")
        
    def choose_branch(self, context: Context) -> str | Iterable[str]:
        self.client = self.hook.get_conn()

        try:
            class_object = json.loads(self.class_object_data)
        except:
            class_object = self._get_file(uri=self.class_object_data, storage_conn_id=self.storage_conn_id)
        
        # check if class_object is a single class object or a list of class objects
        if isinstance(class_object, dict):
            if "classes" not in class_object:
                class_objects = [class_object]
            else:
                class_objects = class_object["classes"]
        else:
            class_objects = class_object
        
        missing_objects = []

        for class_object in class_objects:
            try:
                class_schema = self.client.schema.get(class_object['class'])
                if not self._check_schema(class_object=class_object, class_schema=class_schema):
                    missing_objects.append(class_object['class'])
            except Exception as e:
                if isinstance(e, UnexpectedStatusCodeException):
                    if e.status_code == 404 and 'with response body: None.' in e.message:
                        missing_objects.append(class_object['class'])
                    else:
                        raise(e)
                else:
                    raise(e)

        if missing_objects:    
            print(f"Classes {missing_objects} are not in the current schema.")
            print(f"Branching to task(s) {self.false_tasks}")
            return self.false_tasks
        else:
            print("Requested schema is <= current schema.")
            print(f"Branching to task(s) {self.true_tasks}")
            return self.true_tasks
            
class WeaviateImportDataOperator(_WeaviateBaseOperator):
    """
    Imports data from a parquet file or passed dataframe into Weaviate

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param data: (Optional) A pandas dataframe containing the data to import.
    If not supplying data a 'data_file_path' must be specified.
    :type data: pd.DataFrame

    :param data_file_path: (Optional) Path to a parquet file in supported URI format 
    (ie. file://dir/file, s3://bucket/prefix/key, gs://bucket/prefix/key, 
    abfss://bucket/prefix/key).  If not provided 'data' must be specified as 
    a pandas dataframe.
    :type data_file_path: str

    :param existing: How to handle existing ata.  Options are:
        'skip': If the UUID exists skip import  
        'replace': If the UUID exists replace and reimport  
        'upsert': If an existing object (based on 'primary_key') exists 
            and UUID is different the data will be removed and 
            reimported.
    :type existing: str

    :param primary_key: The property name to use for upsert evaluation.  
    Must be specified if existing=upsert.
    :type primary_key: str
    
    :param error_threshold: Error threshold for imported objects.
        -1: (default) Succeed if at least one object successfully wihtout error.
        0: Fail if any objects have errors on import.
        <N>: Fail if more than N objects have errors on import.
    :type error_threshold: int

    :param class_name: Name of the weaviate class to import data into
    :type class_name: str

    :param embedding_column: Name of the column containing the object's embeddings data
    :type vector_column: str

    :param uuid_column: Name of the column containing the UUID data
    :type uuid_column: str

    :param batched_mode: Whether to use batched mode to import data in batches or one at a time
    with backoff and retry
    :type batched_mode: bool
    
    :param batched_size: Batch size for import.  Default: 1000
    :type batched_size: int

    :param storage_conn_id: If specifying a file in cloud storage specify a 
    Airflow connection ID for reading the file.
    :type storage_conn_id: str

    :param verbose: Whether to return verbose error messages or summarize. If importing
    large numbers of documents verbose settings can result in significant log sizes and 
    Airflow UI sluggishness.
    :type verboxe: boolean

    """
    # Specify the arguments that are allowed to parse with jinja templating
    template_fields = [
        *_WeaviateBaseOperator.template_fields,
        'data',
        'data_file_path',
        'class_name',
        'embedding_column',
        'uuid_column',
        'storage_conn_id',
    ]
    # template_fields_renderers = {"data_file_path": "text"}
    template_ext = ()

    def __init__(self, 
                 class_name: Optional[str] = None,
                 data: Optional[pd.DataFrame] = None,
                 data_file_path: Optional[str] = None, 
                 existing: Optional[str] = 'skip',
                 primary_key: Optional[list] = None,
                 error_threshold: int = -1,
                 storage_conn_id: Optional[str] = None, 
                 embedding_column: Optional[str] = None, 
                 uuid_column: Optional[str] = None,
                 batched_mode: bool = True, 
                 batch_size: int = 1000,
                 verbose: bool = False,
                 **kwargs) -> None:
        super().__init__(**kwargs)

        self.data = data
        self.data_file_path = data_file_path
        self.existing = existing
        self.primary_key = primary_key
        self.error_threshold = error_threshold
        self.class_name = class_name
        self.storage_conn_id = storage_conn_id
        self.embedding_column = embedding_column
        self.uuid_column = uuid_column
        self.batched_mode = batched_mode
        self.batch_size = batch_size
        self.errors: List[Dict[str, Any]] = []
        self.verbose = verbose
    
    @prepare_lineage
    def pre_execute(self, context):
        if self.python_callable:

            op_kwargs = self.python_callable(*self.op_args, **self.op_kwargs)

            if not isinstance(op_kwargs, dict):
                raise AirflowException("python_callable must return a dictionary with op_kwargs for import.")
            
            self.data = op_kwargs.get('data', self.data)
            self.data_file_path = op_kwargs.get('data_file_path', self.data_file_path)
            self.class_name = op_kwargs.get('class_name', self.class_name)
            self.storage_conn_id = op_kwargs.get('storage_conn_id', self.storage_conn_id)
            self.embedding_column = op_kwargs.get('embedding_column', self.embedding_column)
            self.uuid_column = op_kwargs.get('uuid_column', self.uuid_column)
            self.batched_mode = op_kwargs.get('batched_mode', self.batched_mode)
            self.batch_size = op_kwargs.get('batch_size', self.batch_size)
            self.error_threshold = op_kwargs.get('error_threshold', self.error_threshold)
            self.existing = op_kwargs.get('existing', self.existing)
            self.primary_key = op_kwargs.get('primary_key', self.primary_key)
            self.verbose = op_kwargs.get('verbose', self.verbose)
    
    def _check_batch_result(self, batch_result:dict) -> None:
        for item in batch_result:
            if "errors" in item["result"]:
                self.errors.append({"id": item["id"], "errors": item["result"]["errors"]})

    def _remove_for_upsert(self, uuid:str, data_object:dict) -> None:

        existing_objects = self.client.query\
                            .get(properties = [self.primary_key], 
                                 class_name=self.class_name)\
                            .with_additional(['id'])\
                            .with_where({"path": self.primary_key, 
                                         "operator": "Equal", 
                                         "valueText": data_object[self.primary_key]}).do()
        
        existing_objects = [obj for obj in existing_objects['data']['Get'][self.class_name]]

        if len(existing_objects) > 0:

            existing_keys = set([x[self.primary_key] for x in existing_objects])
            if data_object[self.primary_key] not in existing_keys:
                warnings.warn('Primary key schema matches non-key data.  Non-key data may be deleted.')

            existing_uuids = set([x['_additional']['id'] for x in existing_objects])
            if uuid not in existing_uuids:
                print(f'Removing all document chunks with key {self.primary_key} = {data_object[self.primary_key]} for upsert.')
                for remove_uuid in existing_uuids:
                    self.client.data_object.delete(uuid=remove_uuid, class_name=self.class_name)

    def _batched_import(self, df: pd.DataFrame) -> None:
        
        self.client.batch.configure(batch_size=self.batch_size, 
                                    callback=self._check_batch_result)
        
        with self.client.batch as batch:
            for row_id, row in df.iterrows():
                data_object = row.to_dict()
                uuid = data_object.pop(self.uuid_column)

                #upsert objects will hash to a new UUID but need to remove existing based on primary_key
                if self.existing == 'upsert':
                    self._remove_for_upsert(uuid=uuid, data_object=data_object)
                    
                #if the uuid exists we know that the properties are the same
                if self.client.data_object.exists(uuid=uuid, class_name=self.class_name) is True:
                    if self.existing in ['skip', 'upsert']:
                        if self.verbose is True: 
                            print(f'UUID {uuid} exists.  Skipping.') 
                        continue
                    elif self.existing == 'replace': 
                        if self.verbose is True: 
                            print(f'UUID {uuid} exists.  Removing for replacement.')
                        self.client.data_object.delete(uuid=uuid, class_name=self.class_name)

                vector = data_object.pop(self.embedding_column, None)

                added_row = batch.add_data_object(class_name=self.class_name,
                                                  uuid=uuid,
                                                  data_object=data_object,
                                                  vector=vector
                                                  )
                if self.verbose is True: 
                    print(f'Added row {row_id} with UUID {added_row} for batch import.')
 
    def _slow_import(self, df: pd.DataFrame) -> None:
        sleep_backoff = .5
        for row_id, row in df.iterrows():
            data_object = row.to_dict()
            uuid = data_object.pop(self.uuid_column)

            #upsert objects will hash to a new UUID but need to remove existing based on primary_key
            if self.existing == 'upsert':
                self._remove_for_upsert(uuid=uuid, data_object=data_object)
                
            #if the uuid exists we know that the properties are the same
            if self.client.data_object.exists(uuid=uuid, class_name=self.class_name):
                if self.existing == 'skip':
                    if self.verbose is True:
                        print(f'UUID {uuid} exists.  Skipping.')
                    continue
                elif self.existing == 'replace': 
                    if self.verbose is True: 
                        print(f'UUID {uuid} exists.  Removing for replacement.')
                    self.client.data_object.delete(uuid=uuid, class_name=self.class_name)

            vector = data_object.pop(self.embedding_column, None)

            try:
                imported_uuid = self.client.data_object.create(data_object=data_object, 
                                                               uuid=uuid, 
                                                               class_name=self.class_name,
                                                               vector=vector)
                
                if self.verbose is True: 
                    print(f'Added row {row_id} with UUID {imported_uuid}, sleeping for {sleep_backoff} seconds.')
                sleep(sleep_backoff)
            except weaviate.UnexpectedStatusCodeException as e:
                if "Rate limit reached" in str(e):
                    sleep_backoff += 1
                    print(f'Rate limit reached. Sleeping {sleep_backoff} seconds.')
                    sleep(sleep_backoff)
                else:
                    raise e
            except Exception as e:
                error_message = {'type': type(e).__name__, 'params': list(map(str, e.args))}
                error = {'id': uuid, 'errors': [error_message]}
                self.errors.append(error)

    def execute(self, context: Context) -> Any:
        #Param checking is done here instead of init() since params may be set in
        #pre_execute

        if self.existing not in ['skip', 'replace', 'upsert']:
            raise AirflowException("Invalid parameter for 'existing'.  Choices are 'skip', 'replace', 'upsert'")

        self.client = self.hook.get_conn()

        if self.existing == 'upsert':
            if self.primary_key is None:
                raise AirflowException("Must specify 'primary_key' if 'existing=upsert'.")
            else:
                current_schema = self.client.schema.get(class_name=self.class_name)
                key_schema = [prop for prop in current_schema['properties'] if prop['name'] == self.primary_key]
            
                if len(key_schema) < 1:
                    raise AirflowException("Primary key does not exist in current schema.")
                elif key_schema[0]['tokenization'] != 'field':
                    warnings.warn("Tokenization for provided primary_key is not set to 'field'.  This will likely have unintended consequences for upsert.")

        if isinstance(self.data, pd.DataFrame):
            if self.data.empty is True:
                return []
            else:
                df = self.data
        elif self.data_file_path:
            df = self._get_file(self.data_file_path, self.storage_conn_id)
        else:
            raise AirflowException("Must provide 'data' as a pandas dataframe or 'data_file_path' as a URI.")
        
        if not self.class_name:
            raise AirflowException("'class_name' must be provided.")

        if self.uuid_column is None:
            print('No uuid_column provided Generating UUIDs for ingest.')
            self.uuid_column = 'uuid'
            df[self.uuid_column] = df\
                .drop(columns=[self.embedding_column], 
                      inplace=False, 
                      errors='ignore')\
                .apply(lambda row: generate_uuid5(identifier=row.to_dict(), 
                                                  namespace=self.class_name), axis=1)

        if self.batched_mode is True:
            self._batched_import(df)
        else:
            self._slow_import(df)

        if self.verbose is False:
            self.errors = set([error.get('errors')\
                                    .get('error')[0]\
                                    .get('message') for error in self.errors])

        if not self.errors:
            print(f'All data object imported without error.')
            return self.errors
        elif len(self.errors) >= len(df) or self.error_threshold == 0:
            raise AirflowException(f'One or more data objects had errors on import.  Errors are:\n\n{self.errors}')
        elif self.error_threshold == -1:
            print(f'At least one data object imported without error.  Errors are:\n\n{self.errors}')
            return self.errors            
        elif self.error_threshold > 0:
            if len(self.errors) > self.error_threshold:
                raise AirflowException(f'More than {self.error_threshold} data objects had errors on import.  Errors are:\n\n{self.errors}')
            else:
                print(f'Not more than {self.error_threshold} data objects had errors on import.  Errors are:\n\n{self.errors}')
                return self.errors

class WeaviateRetrieveAllOperator(_WeaviateBaseOperator):
    """
    Retrieve all the objects of a class from weaviate and store them in a parquet file

    :param class_name: Name of the weaviate class to retrieve the objects from
    :type class_name: str

    :param with_vector: Whether to include the vector in output. Default: True
    :type with_vector: boolean

    :param output_file: Full path to the parquet file to store the objects in
    supported URI format (ie. file://, s3://, gcs://, abfss://)
    :type output_file: str

    :param storage_conn_id: If specifying an output_file in cloud storage specify a 
    conn_id for writing the file.
    :type storage_conn_id: str
    
    :param replace_existing: Whether to replace an existing output file.
    :type replace_existing: boolean

    """
    template_fields = [
        *_WeaviateBaseOperator.template_fields,
        'output_file',
        'class_name',
        'storage_conn_id',
    ]

    def __init__(self, 
                 class_name: str, 
                 output_file: str, 
                 with_vector: bool = True,
                 storage_conn_id: str | None = None,
                 replace_existing: bool = False,
                 **kwargs
                 ) -> None:
        super().__init__(**kwargs)
        self.class_name = class_name
        self.output_file = output_file
        self.with_vector = with_vector
        self.storage_conn_id = storage_conn_id
        self.replace_existing = replace_existing
    
    def execute(self, context: Context) -> Any:
        self.client = self.hook.get_conn()

        weaviate_version = self.client.get_meta()['version'].split('.')

        if int(weaviate_version[0]) < 1: 
            raise AirflowException(f"Weaviate major version not supported {'.'.join(weaviate_version)}")
        if int(weaviate_version[1]) < 18:
            raise AirflowException(f"Weaviate cursor retrieval not supported in {'.'.join(weaviate_version)}")

        results = []

        last_uuid = None

        while True:
            result = self.client.data_object.get(class_name=self.class_name, 
                                                 after=last_uuid, 
                                                 with_vector=self.with_vector, 
                                                 limit=100) or {}
            if not result.get('objects'):
                break
            results.extend(result['objects'])
            last_uuid = result['objects'][-1]['id']
        
        df = pd.DataFrame(results)

        include_columns = list(set(df.columns).intersection(set(['id', 'vector'])))

        df = pd.concat([pd.json_normalize(df['properties']), 
                                 df[include_columns]], axis=1)

        if len(results) == 0:
            print('Retrieved zero objects.  Check to make sure class exists and is not empty.')
            if self.output_file.endswith('.parquet'):
                file_data = pd.DataFrame()
            elif self.output_file.endswith('.json'):
                file_data = {}

        elif self.output_file.endswith('.parquet'):
            file_data=df
            
        elif self.output_file.endswith('.json'):
            file_data=json.loads(df.to_json())
        
        self._put_file(file_data=file_data, 
                       uri=self.output_file, 
                       storage_conn_id=self.storage_conn_id)
       
        return self.output_file