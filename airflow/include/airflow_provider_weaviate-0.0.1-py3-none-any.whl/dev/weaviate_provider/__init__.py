from importlib.metadata import version

__name__ = "airflow-provider-weaviate"
__version__ = "0.0.1" # version(__name__) or 

## This is needed to allow Airflow to pick up specific metadata fields it needs for certain features.
def get_provider_info():
    return {
        "package-name": "airflow-provider-weaviate",
        "name": "Apache Airflow Provider for Weaviate",
        "description": "An Apache Airflow provider for Weaviate Vector Database.",
        "connection-types": [
            {"connection-type": "weaviate", "hook-class-name": "weaviate_provider.hooks.weaviate.WeaviateHook"}
        ],
        "extra-links": [
            "weaviate_provider.operators.weaviate.WeaviateOperatorHostLink",
            "weaviate_provider.operators.weaviate.WeaviateOperatorRegistryLink"
        ],
        "versions": [__version__],
        "task-decorators": [
        {
            "name": "weaviate_import",
            "class-name": "weaviate_provider.decorators.weaviate.weaviate_import",
        },
        ],
    }
