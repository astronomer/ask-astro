from __future__ import annotations

from typing import Callable, Sequence

from airflow.decorators.base import DecoratedOperator, TaskDecorator, task_decorator_factory

from weaviate_provider.operators.weaviate import WeaviateImportDataOperator

class _WeaviateImportDecoratedOperator(DecoratedOperator, WeaviateImportDataOperator):
    """
    Wraps a Python callable and captures args/kwargs when called for execution.

    Load weaviate vector database from batches of data.  Data can be provided as a 
    pandas dataframe, a path to a pandas dataframe (in URI format) or generated in 
    the python callable and returned as part of a dictionary.

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param python_callable: A decorated python function.  The function is called 
    before the operator execution and must return all required operator parameters 
    as a dictionary.
    :type python_callable: Callable
    """

    custom_operator_name: str = "@task.weaviate_import"

    def __init__(self, 
                 *, 
                 python_callable,
                #  weaviate_conn_id: str | None = None,
                 op_args, 
                 op_kwargs, 
                 **kwargs
            ) -> None:
        
        self.doc_md = python_callable.__doc__
        
        kwargs_to_upstream = {
            "python_callable": python_callable,
            "op_args": op_args,
            "op_kwargs": op_kwargs,
        }
        super().__init__(
            kwargs_to_upstream=kwargs_to_upstream,
            # weaviate_conn_id= weaviate_conn_id,
            python_callable=python_callable,
            op_args=op_args,
            op_kwargs=op_kwargs,
            **kwargs,
        )

def weaviate_import(
    # weaviate_conn_id: str | None = None,
    python_callable: Callable | None = None,
    **kwargs,
) -> TaskDecorator:
    """Wraps a function into an Airflow operator.

    Accepts kwargs for operator kwarg. Can be reused in a single DAG.

    Load a weaviate vector database from batches of data.  Data can be provided as a 
    pandas dataframe, a path to a pandas dataframe (in URI format) or generated in 
    the python callable and returned as part of a dictionary.

    :param weaviate_conn_id: connection ID to run the operator
    :type weaviate_conn_id: str

    :param python_callable: A decorated python function.  The function is called 
    before the operator execution and must return all required operator parameters 
    as a dictionary.
    :type python_callable: Callable

    Arguments for the decorated function include:

    :param data: (Optional) A pandas dataframe containing the data to import.
    If not supplying data a 'data_file_path' must be specified.
    :type data: pd.DataFrame

    :param data_file_path: (Optional) Path to a parquet file in supported URI format 
    (ie. file://dir/file, s3://bucket/prefix/key, gs://bucket/prefix/key, 
    abfss://bucket/prefix/key).  If not provided 'data' must be specified as 
    a pandas dataframe.
    :type data_file_path: str

    :param storage_conn_id: If specifying a file in cloud storage specify a 
    Airflow connection ID for reading the file.
    :type storage_conn_id: str

    :param class_name: Name of the weaviate class to import data into
    :type class_name: str

    :param embedding_column: Name of the column containing the object's embeddings data
    :type vector_column: str

    :param uuid_column: Name of the column containing the UUID data
    :type uuid_column: str

    :param batched_mode: Whether to use batched mode to import data in batches or one at a time
    with backoff and retry
    :type batched_mode: bool

    """
    return task_decorator_factory(
        python_callable=python_callable,
        # weaviate_conn_id=weaviate_conn_id,
        decorated_operator_class=_WeaviateImportDecoratedOperator,
        **kwargs,
    )

