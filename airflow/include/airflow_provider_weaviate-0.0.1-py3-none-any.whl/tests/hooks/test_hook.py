"""
Unittest module to test Hooks.

Requires the unittest, pytest Python libraries.

Run test:

    python3 -m unittest tests.hooks.test_hook.TestWeaviateHook

"""

import logging
import os
import json
import pandas as pd
import pytest
from unittest import mock
from unittest import TestCase

# Import Hook
from weaviate_provider.hooks.weaviate import WeaviateHook
from weaviate_provider.operators.weaviate import WeaviateImportDataOperator
from weaviate_provider.operators.weaviate import WeaviateCreateSchemaOperator
from weaviate import client as weaviate_client


log = logging.getLogger(__name__)

# AIRFLOW_CONN_WEAVIATE_ADMIN='{"conn_type": "weaviate", "host": "http://localhost:8081", "extra": {"token": "adminkey"}}'
# AIRFLOW_CONN_WEAVIATE_ADMIN=f'{{"conn_type": "weaviate", "host": "{os.environ["WCS_TEST_HOST"]}", "extra": {{"token": "{os.environ["WCS_TEST_KEY"]}" }} }}'
# os.environ['AIRFLOW_CONN_WEAVIATE_ADMIN']=AIRFLOW_CONN_WEAVIATE_ADMIN

@mock.patch.dict('os.environ') #, AIRFLOW_CONN_WEAVIATE_ADMIN=AIRFLOW_CONN_WEAVIATE_ADMIN)
class TestWeaviateHook(TestCase):
    """
    Test Weaviate Hook.
    """

    def test_get_conn(self): #, m):

        # Instantiate hook
        hook = WeaviateHook(weaviate_conn_id='weaviate_admin')
        conn = hook.get_conn()

        # Assert conn type
        assert isinstance(conn, weaviate_client.Client)
    
    def test_test_conn(self): #, m):

        # Instantiate hook
        hook = WeaviateHook(weaviate_conn_id='weaviate_admin')
    
        # Assert connection successful
        assert hook.test_connection() == (True, 'Successfully connected to Weaviate.')
    
    def test_check_health(self): #, m):

        # Instantiate hook
        hook = WeaviateHook(weaviate_conn_id='weaviate_admin')
        conn = hook.get_conn()
    
        # Assert HEALTHY
        assert hook.check_health() == 'HEALTHY'
    
    def test_run(self): #, m):
        """
        Test running a query.
        """

        #create schema for test
        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        data_object = [{
            "title": "test1",
            "body": "test_body1",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1234",
            "vector": [-0.12345] * 5
        },
        {
            "title": "test2",
            "body": "test_body2",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1235",
            "vector": [0.12355] * 5
        }]

        #create schema
        response = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        ).execute(context={})

        assert json.dumps(response[0]) == class_obj

        #insert data
        response = WeaviateImportDataOperator(
            task_id='import_operator',
            weaviate_conn_id='weaviate_admin',
            class_name='Article',
            uuid_column='uuid',
            embedding_column='vector',
            data=pd.DataFrame(data_object),
            error_threshold=0,
            batched_mode=False
        ).execute(context={})

        assert response == []

        #     query = '{ Aggregate { Article { meta { count } } } }'
        query = """
        {
            Get {
                Article (
                limit: 2
                nearVector: {
                    vector: [-0.12346, -0.12346, -0.12346, -0.12346, -0.12346]
                }
                ) {
                title
                body
                _additional {
                    distance
                }
                }
            }
        }
        """

        # Instantiate hook
        hook = WeaviateHook(weaviate_conn_id='weaviate_admin')
        
        response = hook.run(query=query)['data']['Get']['Article'][0]

        hook.get_conn().schema.delete_all()
    
        assert response['body'] == 'test_body1' 
        assert response['title'] == 'test1' 
        # assert response['_additional']['distance'] > 5e-08